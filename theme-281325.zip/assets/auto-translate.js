/* ============================================================
   Auto-translate — machine-translates EVERYTHING on the page
   (buttons, labels, stock status, variant options, form
   placeholders, tooltips, product descriptions, etc.) except
   product/group names, which are intentionally left alone via
   SKIP_SELECTORS below.

   Earlier versions of this script skipped any element driven by
   Alpine's x-text/:placeholder/:aria-label/:title bindings, to
   avoid a translation getting instantly overwritten by Alpine
   re-rendering it. In practice that meant most of the storefront
   (buy buttons, stock labels, variant pickers, quantity errors,
   search/ticket placeholders — basically anything reactive) was
   never translated at all, which is why switching language used
   to only translate a handful of plain static strings. Instead of
   skipping those nodes, we now translate them too AND keep
   watching them (via MutationObserver on characterData/attributes)
   so that whenever Alpine resets one back to source-language text,
   it gets re-translated in place.

   IMPORTANT: this does NOT rely on the backend correctly
   rendering <html lang="xx"> / data-default-lang on every page
   or route. That dependency turned out to be unreliable across
   templates, which is why translation could silently do nothing
   even when a language was selected. Instead, the chosen
   language is the single source of truth, kept in localStorage,
   and applied immediately by JS the moment it's picked (see
   window.saChooseLanguage, called from language-selector.njk),
   then re-applied on every subsequent page load. It no longer
   matters what the server thinks the current language is.

   Uses the free, keyless MyMemory API. Results are cached in
   localStorage so repeat visits / navigations are instant and
   we don't refetch the same string twice.

   NOTE: this calls a third-party API (api.mymemory.translated.net)
   from the browser. If your host's Content-Security-Policy blocks
   outbound requests to domains it doesn't allowlist, translation
   will silently no-op (the page falls back to the original text —
   nothing breaks, it just won't translate). If that happens here,
   ask SellAuth support to allow connect-src to that domain, or
   swap SOURCE_ENDPOINT below for a translation API your host does
   allow.
   ============================================================ */
(function () {
  var SOURCE_ENDPOINT = 'https://api.mymemory.translated.net/get';
  var CACHE_PREFIX = 'sa_auto_i18n_';
  var LANG_STORAGE_KEY = 'sa_auto_i18n_lang';
  var SKIP_TAGS = { SCRIPT: 1, STYLE: 1, NOSCRIPT: 1, TEXTAREA: 1, INPUT: 1, SELECT: 1, IFRAME: 1, SVG: 1, KBD: 1, CODE: 1, PRE: 1 };

  // Attributes that hold user-facing text even though it's not a text node
  // (search boxes, ticket forms, buttons, the "dismiss" icon button, etc.).
  var TRANSLATABLE_ATTRS = ['placeholder', 'aria-label', 'title'];

  var SKIP_SELECTORS = [
    '.notranslate',
    '.sa-product-card-title',
    '.sa-page-product-title',
    '.sa-fc-card__name',
    '[data-no-i18n]',
    // Language names/codes in the language switcher itself are endonyms
    // ("Español", "Deutsch") shown next to a hreflang code — translating
    // them would make the picker harder to use, not easier.
    '.sa-language-selector',
  ];

  var html = document.documentElement;
  var source = (html.getAttribute('data-default-lang') || 'en').split('-')[0].toLowerCase();

  var indicatorEl = null;
  var activeRuns = 0;

  function ensureIndicator() {
    if (indicatorEl) return indicatorEl;
    indicatorEl = document.createElement('div');
    indicatorEl.className = 'sa-i18n-indicator notranslate';
    indicatorEl.setAttribute('aria-live', 'polite');
    indicatorEl.innerHTML = '<span class="sa-i18n-indicator__spinner"></span><span>Translating…</span>';
    document.body.appendChild(indicatorEl);
    return indicatorEl;
  }

  function beginRun() {
    activeRuns++;
    if (activeRuns === 1) {
      requestAnimationFrame(function () { ensureIndicator().classList.add('is-visible'); });
    }
  }
  function endRun() {
    activeRuns = Math.max(0, activeRuns - 1);
    if (activeRuns === 0 && indicatorEl) indicatorEl.classList.remove('is-visible');
  }

  function hashText(str) {
    var h = 0;
    for (var i = 0; i < str.length; i++) { h = (h << 5) - h + str.charCodeAt(i); h |= 0; }
    return h.toString(36) + '_' + str.length;
  }
  function cacheGet(lang, text) {
    try { return localStorage.getItem(CACHE_PREFIX + lang + '_' + hashText(text)); } catch (e) { return null; }
  }
  function cacheSet(lang, text, translated) {
    try { localStorage.setItem(CACHE_PREFIX + lang + '_' + hashText(text), translated); } catch (e) {}
  }
  function getSavedLang() {
    try { return localStorage.getItem(LANG_STORAGE_KEY) || source; } catch (e) { return source; }
  }
  function saveLang(code) {
    try { localStorage.setItem(LANG_STORAGE_KEY, code); } catch (e) {}
  }

  function isSkipped(el) {
    while (el) {
      if (el.nodeType === 1) {
        if (SKIP_TAGS[el.tagName]) return true;
        if (el.hasAttribute && el.hasAttribute('data-no-i18n')) return true;
        for (var i = 0; i < SKIP_SELECTORS.length; i++) {
          if (el.matches && el.matches(SKIP_SELECTORS[i])) return true;
        }
      }
      el = el.parentElement;
    }
    return false;
  }

  // Separate (looser) skip check for the *attribute* translation pass: the
  // element that owns placeholder/aria-label/title is very often an INPUT
  // or BUTTON itself, so we must not bail out just because the element's
  // own tag is in SKIP_TAGS — only bail if an *ancestor* is a skip tag,
  // or the usual notranslate/product-name/data-no-i18n rules apply.
  function isSkippedForAttr(el) {
    var node = el;
    while (node) {
      if (node.nodeType === 1) {
        if (node !== el && SKIP_TAGS[node.tagName]) return true;
        if (node.hasAttribute && node.hasAttribute('data-no-i18n')) return true;
        for (var i = 0; i < SKIP_SELECTORS.length; i++) {
          if (node.matches && node.matches(SKIP_SELECTORS[i])) return true;
        }
      }
      node = node.parentElement;
    }
    return false;
  }

  function collectTextNodes(root) {
    var nodes = [];
    var walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT, {
      acceptNode: function (node) {
        var val = node.nodeValue;
        if (!val || !val.trim() || val.trim().length < 2) return NodeFilter.FILTER_REJECT;
        if (!/[a-zA-Z\u00C0-\u024F]{2,}/.test(val)) return NodeFilter.FILTER_REJECT; // skip pure numbers/symbols/prices
        if (isSkipped(node.parentElement)) return NodeFilter.FILTER_REJECT;
        return NodeFilter.FILTER_ACCEPT;
      }
    });
    var n;
    while ((n = walker.nextNode())) nodes.push(n);
    return nodes;
  }

  // MyMemory limits requests to ~500 chars; split long text (e.g.
  // product descriptions) into sentence-ish chunks and rejoin.
  function chunk(text, max) {
    if (text.length <= max) return [text];
    var parts = text.split(/(?<=[.!?])\s+/);
    var out = [];
    var cur = '';
    parts.forEach(function (p) {
      if ((cur + ' ' + p).trim().length > max) { if (cur) out.push(cur.trim()); cur = p; }
      else cur = (cur + ' ' + p).trim();
    });
    if (cur) out.push(cur.trim());
    return out.length ? out : [text.slice(0, max)];
  }

  // Curated, exact translations for short, frequently-repeated storefront
  // phrases (button labels, stock states) that appear as plain hardcoded
  // text in a few components rather than going through the theme's proper
  // locale files. Checked before the API call; anything not listed here
  // still falls back to MyMemory as before, so coverage only ever gets
  // better, never worse.
  var DICTIONARY = {
    'view product':      { es: 'Ver producto', fr: 'Voir le produit', de: 'Produkt ansehen', it: 'Vedi prodotto', pt: 'Ver produto', nl: 'Product bekijken', ru: 'Смотреть товар', pl: 'Zobacz produkt', tr: 'Ürünü görüntüle', uk: 'Переглянути товар', ro: 'Vezi produsul', ar: 'عرض المنتج', zh: '查看产品', ja: '商品を見る', ko: '제품 보기' },
    'buy now':           { es: 'Comprar ahora', fr: 'Acheter maintenant', de: 'Jetzt kaufen', it: 'Acquista ora', pt: 'Comprar agora', nl: 'Nu kopen', ru: 'Купить сейчас', pl: 'Kup teraz', tr: 'Şimdi satın al', uk: 'Купити зараз', ro: 'Cumpără acum', ar: 'اشترِ الآن', zh: '立即购买', ja: '今すぐ購入', ko: '지금 구매' },
    'shop now':          { es: 'Comprar ahora', fr: 'Acheter maintenant', de: 'Jetzt kaufen', it: 'Acquista ora', pt: 'Comprar agora', nl: 'Nu kopen', ru: 'Купить сейчас', pl: 'Kup teraz', tr: 'Şimdi satın al', uk: 'Купити зараз', ro: 'Cumpără acum', ar: 'اشترِ الآن', zh: '立即购买', ja: '今すぐ購入', ko: '지금 구매' },
    'view group':        { es: 'Ver grupo', fr: 'Voir le groupe', de: 'Gruppe ansehen', it: 'Vedi gruppo', pt: 'Ver grupo', nl: 'Groep bekijken', ru: 'Смотреть группу', pl: 'Zobacz grupę', tr: 'Grubu görüntüle', uk: 'Переглянути групу', ro: 'Vezi grupul', ar: 'عرض المجموعة', zh: '查看分组', ja: 'グループを見る', ko: '그룹 보기' },
    'in stock':          { es: 'En stock', fr: 'En stock', de: 'Auf Lager', it: 'Disponibile', pt: 'Em estoque', nl: 'Op voorraad', ru: 'В наличии', pl: 'Dostępny', tr: 'Stokta', uk: 'В наявності', ro: 'În stoc', ar: 'متوفر', zh: '有货', ja: '在庫あり', ko: '재고 있음' },
    'out of stock':      { es: 'Agotado', fr: 'Rupture de stock', de: 'Nicht vorrätig', it: 'Esaurito', pt: 'Esgotado', nl: 'Niet op voorraad', ru: 'Нет в наличии', pl: 'Niedostępny', tr: 'Stokta yok', uk: 'Немає в наявності', ro: 'Stoc epuizat', ar: 'غير متوفر', zh: '缺货', ja: '在庫切れ', ko: '품절' },
    'add to cart':       { es: 'Añadir al carrito', fr: 'Ajouter au panier', de: 'In den Warenkorb', it: 'Aggiungi al carrello', pt: 'Adicionar ao carrinho', nl: 'In winkelwagen', ru: 'Добавить в корзину', pl: 'Dodaj do koszyka', tr: 'Sepete ekle', uk: 'Додати в кошик', ro: 'Adaugă în coș', ar: 'أضف إلى السلة', zh: '加入购物车', ja: 'カートに追加', ko: '장바구니에 담기' },
    'starting at':       { es: 'Desde', fr: 'À partir de', de: 'Ab', it: 'A partire da', pt: 'A partir de', nl: 'Vanaf', ru: 'От', pl: 'Od', tr: 'Başlangıç', uk: 'Від', ro: 'De la', ar: 'يبدأ من', zh: '起', ja: '〜から', ko: '부터' },
    'featured products': { es: 'Productos destacados', fr: 'Produits en vedette', de: 'Empfohlene Produkte', it: 'Prodotti in evidenza', pt: 'Produtos em destaque', nl: 'Uitgelichte producten', ru: 'Популярные товары', pl: 'Polecane produkty', tr: 'Öne çıkan ürünler', uk: 'Популярні товари', ro: 'Produse recomandate', ar: 'منتجات مميزة', zh: '精选产品', ja: 'おすすめ商品', ko: '추천 상품' },
    'shop by category':  { es: 'Comprar por categoría', fr: 'Acheter par catégorie', de: 'Nach Kategorie einkaufen', it: 'Acquista per categoria', pt: 'Comprar por categoria', nl: 'Winkelen per categorie', ru: 'Покупки по категориям', pl: 'Kupuj według kategorii', tr: 'Kategoriye göre alışveriş', uk: 'Покупки за категоріями', ro: 'Cumpără după categorie', ar: 'تسوق حسب الفئة', zh: '按分类购物', ja: 'カテゴリーで探す', ko: '카테고리별 쇼핑' },
    'instant delivery':  { es: 'Entrega instantánea', fr: 'Livraison instantanée', de: 'Sofortige Lieferung', it: 'Consegna istantanea', pt: 'Entrega instantânea', nl: 'Directe levering', ru: 'Мгновенная доставка', pl: 'Natychmiastowa dostawa', tr: 'Anında teslimat', uk: 'Миттєва доставка', ro: 'Livrare instantă', ar: 'توصيل فوري', zh: '即时发货', ja: '即時配送', ko: '즉시 배송' },
    'read more':         { es: 'Leer más', fr: 'Lire la suite', de: 'Mehr lesen', it: 'Leggi di più', pt: 'Leia mais', nl: 'Lees meer', ru: 'Читать далее', pl: 'Czytaj więcej', tr: 'Devamını oku', uk: 'Читати далі', ro: 'Citește mai mult', ar: 'اقرأ المزيد', zh: '阅读更多', ja: '続きを読む', ko: '더 보기' },
    'maybe later':       { es: 'Quizás más tarde', fr: 'Plus tard peut-être', de: 'Vielleicht später', it: 'Forse più tardi', pt: 'Talvez mais tarde', nl: 'Misschien later', ru: 'Может быть позже', pl: 'Może później', tr: 'Belki sonra', uk: 'Може пізніше', ro: 'Poate mai târziu', ar: 'ربما لاحقًا', zh: '也许稍后', ja: 'また今度', ko: '나중에 할게요' },
    'no thanks':         { es: 'No, gracias', fr: 'Non merci', de: 'Nein, danke', it: 'No, grazie', pt: 'Não, obrigado', nl: 'Nee, bedankt', ru: 'Нет, спасибо', pl: 'Nie, dziękuję', tr: 'Hayır, teşekkürler', uk: 'Ні, дякую', ro: 'Nu, mulțumesc', ar: 'لا شكرًا', zh: '不用了谢谢', ja: '結構です', ko: '괜찮아요' },
    'quick view':        { es: 'Vista rápida', fr: 'Aperçu rapide', de: 'Schnellansicht', it: 'Anteprima rapida', pt: 'Visualização rápida', nl: 'Snel bekijken', ru: 'Быстрый просмотр', pl: 'Szybki podgląd', tr: 'Hızlı bakış', uk: 'Швидкий перегляд', ro: 'Previzualizare rapidă', ar: 'عرض سريع', zh: '快速查看', ja: 'クイックビュー', ko: '빠른 보기' }
  };

  // The free MyMemory API sometimes goes slow or starts rate-limiting
  // without ever actually failing the request — the fetch just hangs.
  // With no timeout, one stuck request used to block its whole worker
  // (and a chunk of the queue) for as long as the browser was willing to
  // wait. Each attempt now gets a hard timeout, and one retry, before we
  // give up on that string for this run and just keep the original text.
  var REQUEST_TIMEOUT_MS = 4000;

  function fetchWithTimeout(url, ms) {
    var controller = new AbortController();
    var timer = setTimeout(function () { controller.abort(); }, ms);
    return fetch(url, { signal: controller.signal }).finally(function () {
      clearTimeout(timer);
    });
  }

  async function requestTranslation(text, target) {
    var url = SOURCE_ENDPOINT + '?q=' + encodeURIComponent(text) + '&langpair=' + source + '|' + target;
    var res = await fetchWithTimeout(url, REQUEST_TIMEOUT_MS);
    var data = await res.json();
    var out = (data && data.responseData && data.responseData.translatedText) ? data.responseData.translatedText : text;
    var looksBroken = /mymemory|quota|warning/i.test(out) || (text.length <= 4 && out.length > text.length * 6);
    return looksBroken ? text : out;
  }

  async function translateChunk(text, target) {
    var dictHit = DICTIONARY[text.trim().toLowerCase()];
    if (dictHit && dictHit[target]) return dictHit[target];

    var cached = cacheGet(target, text);
    if (cached) return cached;

    for (var attempt = 0; attempt < 2; attempt++) {
      try {
        var out = await requestTranslation(text, target);
        cacheSet(target, text, out);
        return out;
      } catch (e) {
        // Timed out, aborted, offline, or CSP-blocked — try once more,
        // then fall back to the original text instead of hanging.
      }
    }
    return text;
  }

  async function translateText(text, target) {
    var pieces = chunk(text, 480);
    var translated = [];
    for (var i = 0; i < pieces.length; i++) translated.push(await translateChunk(pieces[i], target));
    return translated.join(' ');
  }

  var originalText = new WeakMap();

  // Tracks the exact string we last wrote into a text node/attribute, so
  // the MutationObserver (below) can tell "Alpine just changed this" apart
  // from "that's just our own translation landing" and avoid re-triggering
  // itself in a loop.
  var lastSelfWrite = new WeakMap(); // textNode -> string
  var attrLastSelfWrite = new WeakMap(); // element -> { attrName: string }

  function applyTranslation(node, full, original, translated) {
    if (!node.isConnected) return;
    var el = node.parentElement;
    var next = full.replace(original, translated);
    if (!el || next === full) {
      lastSelfWrite.set(node, next);
      node.nodeValue = next;
      return;
    }
    el.classList.add('sa-i18n-updating');
    setTimeout(function () {
      lastSelfWrite.set(node, next);
      node.nodeValue = next;
      requestAnimationFrame(function () {
        requestAnimationFrame(function () { el.classList.remove('sa-i18n-updating'); });
      });
    }, 90);
  }

  // Throttle re-translation of the *same* node/attribute so fast-repeating
  // Alpine reactivity (live counters, polling, etc.) can't spam the
  // translation API. Genuine one-off changes (picking a variant, an error
  // message appearing) are still translated almost immediately.
  var lastMutationAttempt = new WeakMap();
  var MUTATION_THROTTLE_MS = 2500;
  function throttledForMutation(key) {
    var now = Date.now();
    var last = lastMutationAttempt.get(key);
    if (last && now - last < MUTATION_THROTTLE_MS) return true;
    lastMutationAttempt.set(key, now);
    return false;
  }

  // Re-translates a single text node whose content just changed under us
  // (e.g. Alpine re-rendered it with a fresh — but still source-language —
  // string). Treats the new value as the string to translate from scratch.
  async function translateSingleTextNode(node, target) {
    if (!node.isConnected || throttledForMutation(node)) return;
    var text = node.nodeValue;
    if (!text || text.trim().length < 2) return;
    if (!/[a-zA-Z\u00C0-\u024F]{2,}/.test(text)) return;
    originalText.set(node, text);
    beginRun();
    try {
      var translated = await translateText(text.trim(), target);
      if (translated) applyTranslation(node, text, text.trim(), translated);
    } finally {
      endRun();
    }
  }

  function collectAttrTargets(root) {
    var els = [];
    if (root.nodeType === 1 && root.matches) {
      var sel = TRANSLATABLE_ATTRS.map(function (a) { return '[' + a + ']'; }).join(',');
      if (root.matches(sel)) els.push(root);
      if (root.querySelectorAll) els = els.concat(Array.prototype.slice.call(root.querySelectorAll(sel)));
    }
    var out = [];
    els.forEach(function (el) {
      if (isSkippedForAttr(el)) return;
      TRANSLATABLE_ATTRS.forEach(function (attr) {
        if (!el.hasAttribute(attr)) return;
        var val = el.getAttribute(attr);
        if (!val || val.trim().length < 2) return;
        if (!/[a-zA-Z\u00C0-\u024F]{2,}/.test(val)) return;
        out.push({ el: el, attr: attr });
      });
    });
    return out;
  }

  var attrOriginal = new WeakMap(); // element -> { attrName: original string }

  async function runAttrs(root, target) {
    var targets = collectAttrTargets(root);
    if (!targets.length) return;
    beginRun();
    try {
      var i = 0;
      async function worker() {
        while (i < targets.length) {
          var item = targets[i++];
          var el = item.el, attr = item.attr;
          if (!el.isConnected) continue;
          if (!attrOriginal.has(el)) attrOriginal.set(el, {});
          var origMap = attrOriginal.get(el);
          if (!(attr in origMap)) origMap[attr] = el.getAttribute(attr);
          var src = origMap[attr];
          if (!src || src.trim().length < 2) continue;
          var translated = await translateText(src.trim(), target);
          if (translated && el.isConnected) {
            if (!attrLastSelfWrite.has(el)) attrLastSelfWrite.set(el, {});
            attrLastSelfWrite.get(el)[attr] = translated;
            el.setAttribute(attr, translated);
          }
        }
      }
      var workers = [];
      for (var w = 0; w < 8; w++) workers.push(worker());
      await Promise.all(workers);
    } finally {
      endRun();
    }
  }

  // Re-translates one attribute after Alpine (or a poll/refresh) reset it
  // back to source-language text.
  async function translateSingleAttr(el, attr, target) {
    if (!el.isConnected || throttledForMutation(el)) return;
    if (!el.hasAttribute(attr)) return;
    var val = el.getAttribute(attr);
    if (!val || val.trim().length < 2) return;
    if (!attrOriginal.has(el)) attrOriginal.set(el, {});
    attrOriginal.get(el)[attr] = val;
    var translated = await translateText(val.trim(), target);
    if (translated && el.isConnected) {
      if (!attrLastSelfWrite.has(el)) attrLastSelfWrite.set(el, {});
      attrLastSelfWrite.get(el)[attr] = translated;
      el.setAttribute(attr, translated);
    }
  }

  async function run(root, target) {
    var nodes = collectTextNodes(root);
    var queue = [];
    nodes.forEach(function (node) {
      if (!originalText.has(node)) originalText.set(node, node.nodeValue);
      var src = originalText.get(node);
      if (src.trim().length < 2) return;
      queue.push({ node: node, text: src.trim(), full: src });
    });

    if (!queue.length) return;

    beginRun();
    try {
      var concurrency = 8;
      var i = 0;
      async function worker() {
        while (i < queue.length) {
          var item = queue[i++];
          var translated = await translateText(item.text, target);
          if (translated) applyTranslation(item.node, item.full, item.text, translated);
        }
      }
      var workers = [];
      for (var w = 0; w < concurrency; w++) workers.push(worker());
      await Promise.all(workers);
    } finally {
      endRun();
    }
  }

  var observer = null;
  var currentTarget = null;

  // Watches for two things Alpine does constantly on this theme:
  //  1) new DOM added (x-for lists like the variant picker, ticket replies
  //     arriving via polling, modals opening) — handled as before.
  //  2) EXISTING text/attributes being overwritten in place by x-text /
  //     :placeholder / :aria-label / :title bindings re-evaluating (buy
  //     button label, stock status, quantity errors, etc.). This is new:
  //     previously these were simply excluded from translation entirely,
  //     which is why switching language translated only plain static text
  //     and left most buttons/labels/options in the original language.
  function watchForNewContent() {
    if (observer) return;
    var pendingTimer = null;
    var pendingAdded = [];
    var pendingText = [];
    var pendingAttrs = [];
    observer = new MutationObserver(function (mutations) {
      if (!currentTarget || currentTarget === source) return;
      mutations.forEach(function (m) {
        if (m.type === 'childList') {
          m.addedNodes && m.addedNodes.forEach(function (n) {
            if (n.nodeType === 1) pendingAdded.push(n);
          });
        } else if (m.type === 'characterData') {
          var node = m.target;
          if (lastSelfWrite.get(node) === node.nodeValue) return; // our own write, not Alpine
          if (node.parentElement && isSkipped(node.parentElement)) return;
          pendingText.push(node);
        } else if (m.type === 'attributes') {
          var el = m.target;
          var attr = m.attributeName;
          var selfMap = attrLastSelfWrite.get(el);
          if (selfMap && selfMap[attr] === el.getAttribute(attr)) return; // our own write
          pendingAttrs.push({ el: el, attr: attr });
        }
      });
      if (!pendingAdded.length && !pendingText.length && !pendingAttrs.length) return;
      if (pendingTimer) clearTimeout(pendingTimer);
      pendingTimer = setTimeout(function () {
        var added = pendingAdded, text = pendingText, attrs = pendingAttrs;
        pendingAdded = []; pendingText = []; pendingAttrs = [];
        added.forEach(function (n) { if (n.isConnected) { run(n, currentTarget); runAttrs(n, currentTarget); } });
        text.forEach(function (n) { translateSingleTextNode(n, currentTarget); });
        attrs.forEach(function (item) {
          if (item.el.isConnected && !isSkippedForAttr(item.el)) translateSingleAttr(item.el, item.attr, currentTarget);
        });
      }, 250);
    });
    observer.observe(document.body, {
      childList: true,
      subtree: true,
      characterData: true,
      attributes: true,
      attributeFilter: TRANSLATABLE_ATTRS,
    });
  }

  // Called directly by language-selector.njk the moment a shopper picks a
  // language — translates immediately, in place, with no page reload and
  // no dependency on the backend threading a lang/defaultLang value
  // through every route (that dependency is what made translation
  // silently do nothing before). Picking the shop's own default language
  // just reloads the page, the simplest reliable way to restore every bit
  // of original text, including anything a later mutation added.
  // Keeps the language-selector button/dropdown in sync with whatever
  // language is actually active. Used both right after a manual pick AND
  // on every fresh page load when restoring a saved language — previously
  // only the former happened, so navigating to a new page (any link that
  // isn't a full reload) kept showing the shop's original/default language
  // in the selector even though the page content was already translated,
  // which looked like the switcher was stuck on the wrong language.
  function syncLanguageUI(code) {
    html.setAttribute('lang', code);
    document.querySelectorAll('[data-sa-lang-label]').forEach(function (el) { el.textContent = code; });
    document.querySelectorAll('[data-sa-lang-option]').forEach(function (el) {
      var active = el.getAttribute('data-sa-lang-option') === code;
      el.setAttribute('aria-selected', active ? 'true' : 'false');
      el.classList.toggle('bg-accent-500/10', active);
      el.classList.toggle('text-accent-500', active);
      el.classList.toggle('font-medium', active);
    });
  }

  window.saChooseLanguage = function (code, isDefault) {
    code = (code || '').split('-')[0].toLowerCase();
    if (isDefault || code === source) {
      try { localStorage.removeItem(LANG_STORAGE_KEY); } catch (e) {}
      location.reload();
      return;
    }
    saveLang(code);
    currentTarget = code;
    syncLanguageUI(code);
    watchForNewContent();
    run(document.body, code);
    runAttrs(document.body, code);
  };

  function start() {
    var saved = getSavedLang();
    if (!saved || saved === source) return; // nothing to do on the shop's original language
    currentTarget = saved;
    syncLanguageUI(saved);
    watchForNewContent();
    run(document.body, saved);
    runAttrs(document.body, saved);
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', start);
  } else {
    start();
  }
})();
